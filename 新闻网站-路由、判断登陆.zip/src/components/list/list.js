import React,{Component} from 'react';
import Axios from "axios"
import "./list.css"

class List extends Component{
    constructor(){
        super()
        this.state={
            data:{
                data:[]
            },
            // id:1
        }
    }

    componentWillMount() {
        var id=this.props.match.params.id
        // console.log(id)
        this.getDadta()
    }

    componentWillReceiveProps(){
        
        setTimeout(()=>{
               this.getDadta()
        },0)
        
    }
    getDadta(){
        var id=this.props.match.params.id
        console.log(this.props.match)
        Axios.get('http://www.dell-lee.com/react/api/list.json?id='+id).then(d=>{
        
            this.setState({
                id:id,
                data:d.data
            })
        })
    }

    render(){
        return (<div className="List">
            <ul>
                {
                    this.state.data.data.map((item,i)=>{
                        return <li key={i}>{item.title}</li>
                    })
                }
            </ul>
        </div>)
    }
}
export default List;