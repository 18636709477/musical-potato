import React,{Component} from 'react';


class Viptemp extends Component{
    componentWillMount(){
        var userid=localStorage.getItem("userId")
        console.log(!userid,!undefined)
        if (!userid) {
            this.props.history.push('/')
        }

    }
    render(){
        return (
            <div>
                <h1>VIP</h1>
            </div>
        )
    }
}
export default Viptemp