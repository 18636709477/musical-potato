import React,{Component} from 'react';
import Axios from "axios"

class User extends Component{
    constructor(){
        super()
        this.state={
            loginShow:false,
            loginState:false
        }
    }
    componentWillMount(){
        var off=!!localStorage.getItem("userId")
            this.setState({
                loginState:off
            })
    }
    gotoVip=()=>{
        var userid=localStorage.getItem("userId")
        // console.log(!userid,!undefined)
        // if (userid) {
            this.props.history.push('/vip')
        // }else{
        //     alert('请登录')
        // }

    }
    openLogin=()=>{
        this.setState({
            loginShow:true,
            user:'',
            pass:''
        })
    }
    closeLogin=()=>{
        this.setState({
            loginShow:false
        })
    }
    changeUser=(e)=>{
        // console.log(e.target.value)
        this.setState({
            user:e.target.value
        })
    }
    changePass=(e)=>{
        // console.log(e.target.value)
        this.setState({
            pass:e.target.value
        })
    }
    onLogin=()=>{
        Axios.get('http://www.dell-lee.com/react/api/login.json?user='+this.state.user+'&password='+this.state.pass).then(d=>{
            console.log(d.data.data.login)
            if (d.data.data.login) {
                localStorage.setItem('userId',this.state.user)
                this.setState({
                    loginState:true
                })
            }
        })
    }
    onLogout=()=>{
        localStorage.removeItem('userId')
        this.props.history.push('/')
        this.setState({
            loginState:false
        })
    }

    render(){
        console.log(this.state.loginState)
        return (
            <div className="user">
                {
                    this.state.loginState?<button onClick={this.onLogout}>退出</button>:<button onClick={this.openLogin} >登录</button>
                }
                
                <button onClick={this.gotoVip} >VIP</button>
                {
                    this.state.loginShow?<div className="zhezhao">
                            <div className="login" >
                                <p><input type="text" onChange={this.changeUser} value={this.state.user}></input></p>
                                <p><input type="password" onChange={this.changePass} value={this.state.pass}></input></p>
                                <p>
                                    {/* <button onClick={this.onLogout}>退出</button> */}
                                    <button onClick={this.onLogin}>登录</button>
                                    <button onClick={this.closeLogin}>取消</button>
                                </p>
                            </div>
                        </div>:''
                }
                

            </div>
        )
    }
}



export default User