import React,{Component} from 'react';
import "./head.css"
import { Link } from 'react-router-dom';

class Header extends Component{
    constructor(){
        super()
        this.state={
            TabBer:[
                {name:'tab-1',type:1},
                {name:'tab-2',type:2},
                {name:'tab-3',type:3},
                {name:'tab-4',type:4},
                {name:'tab-5',type:5},
                {name:'tab-6',type:6},
                {name:'tab-7',type:7}
            ]
        }
    }
    componentDidMount(){
        console.log('成功载入子组件')
    }


    render(){
        return (
            <div className="header">
                {
                    this.state.TabBer.map((item,i)=>{
                        return (<Link 
                            to={"/list/"+item.type}
                            className="block" 
                            type={item.type} 
                            key={i}
                            // onClick={this.cutTabBer}
                            >{item.name} 
                        </Link>)
                    })
                }
                
            </div>
        )
    }

}

export default Header