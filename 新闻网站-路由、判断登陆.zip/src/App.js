import React from 'react';
import './App.css';
import { BrowserRouter, Route ,Router} from 'react-router-dom';

import Header from "./components/head/head.js"
import List from "./components/list/list.js"
import User from "./components/user/user.js"
import Viptemp from "./components/vip/vip.js"








class App extends React.Component{


    render(){
        return (
            <BrowserRouter>
                <div>
                    <Route component={Header}/>
                    <Route component={User}/>
                    <Route path='/list/:id' component={List}/>
                    {/* <Route path='/' component={List}/> */}
                    {/* <Login></Login> */}
                    <Route path="/vip" parent={this} component={Viptemp}></Route>
                </div>
            </BrowserRouter>
        )
    }
}

export default App;
